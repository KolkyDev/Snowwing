@echo off
cd /d "%~dp0"
if exist "DesktopSnow.exe" (
  "DesktopSnow.exe" --stop
  exit /b
)
if exist "dist\DesktopSnow.exe" (
  "dist\DesktopSnow.exe" --stop
  exit /b
)
python snow.py --stop
