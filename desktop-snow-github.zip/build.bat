@echo off
cd /d "%~dp0"
if not exist ".build-env\Scripts\python.exe" (
  python -m venv .build-env
  if errorlevel 1 goto fail
)
".build-env\Scripts\python.exe" -m pip install -r requirements-build.txt
if errorlevel 1 goto fail
".build-env\Scripts\python.exe" build.py
if errorlevel 1 goto fail
echo.
echo Ready: dist\DesktopSnow.exe
pause
exit /b 0
:fail
echo Build failed. Check that Python 3.10 or newer is installed.
pause
exit /b 1
