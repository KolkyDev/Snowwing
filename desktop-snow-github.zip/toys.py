"""Mass-conserving snowballs and stackable snow sculptures."""
from dataclasses import dataclass
import math


@dataclass
class Snowball:
    uid: int
    x: float
    y: float
    mass: float
    vx: float = 0.0
    vy: float = 0.0
    support: object = None

    @property
    def radius(self):
        return math.sqrt(self.mass/(math.pi*.42))


class SnowToys:
    MAX_BALLS=24

    def __init__(self,world):
        self.world=world
        self.balls={}
        self.held=None
        self.next_uid=1
        self.last_cursor=None
        self.was_sculpting=False
        self.gaze={}
        self.waves={}

    def _new(self,x,y,mass):
        ball=Snowball(self.next_uid,x,y,mass)
        self.next_uid+=1
        self.balls[ball.uid]=ball
        return ball

    def _ancestor(self,uid,ancestor):
        seen=set()
        while uid in self.balls and uid not in seen:
            if uid==ancestor: return True
            seen.add(uid)
            support=self.balls[uid].support
            if not support or support[0]!='ball': return False
            uid=support[1]
        return False

    def _stack_hit(self,ball,old_y,new_y):
        candidates=[]
        for other in self.balls.values():
            if other.uid==ball.uid or self._ancestor(other.uid,ball.uid): continue
            if other.uid==self.held or ball.radius>other.radius*.95: continue
            top=other.y-other.radius
            contact=top-ball.radius+min(ball.radius,other.radius)*.12
            if abs(ball.x-other.x)<max(4,other.radius*.60) and old_y<=contact+1 and new_y>=contact:
                if not self.world.hidden(other.x,top):
                    candidates.append((contact,other))
        return min(candidates,key=lambda pair:pair[0]) if candidates else None

    def _collect(self,cursor,distance,dt):
        x,y=cursor
        if len(self.balls)>=self.MAX_BALLS and self.held is None: return
        for key,(left,top,right) in self.world.roofs.items():
            if not left<=x<right: continue
            bank=self.world.banks[key]
            height=bank.height_at(x-left)
            if height<.1 or not top-height-18<=y<=top+1: continue
            ball=self.balls.get(self.held)
            if ball and ball.radius>=28: return
            radius=12 if ball is None else max(12,ball.radius)
            fraction=1-math.exp(-(distance+dt*2)/20)
            removed=bank.scoop(x-left,radius,min(.65,fraction))
            mass=sum(m for _,m in removed)
            if not mass: continue
            capacity=max(0,math.pi*.42*28**2-(ball.mass if ball else 0))
            if mass>capacity:
                volume=sum(m/bank.packing[min(bank.count-1,int(local/bank.dx))]
                           for local,m in removed)
                bank.deposit(x-left,mass-capacity,density=mass/volume)
                mass=capacity
            if mass<=0: return
            if ball is None:
                ball=self._new(x,y,mass)
                self.held=ball.uid
            else: ball.mass+=mass
            ball.x=x
            ball.y=top-height-ball.radius
            return

    def react(self,cursor,sculpt=False):
        gaze={}; waves={}
        for base,middle,head in self.snowmen():
            until,cooldown=self.waves.get(base.uid,(0,0))
            if cursor and not sculpt and not self.world.hidden(*cursor):
                dx=cursor[0]-head.x; dy=cursor[1]-head.y
                if dx*dx+dy*dy<160**2:
                    gaze[head.uid]=-1 if dx<-12 else 1 if dx>12 else 0
                    if self.world.time>=cooldown:
                        until=self.world.time+.9; cooldown=self.world.time+12
            waves[base.uid]=(until,cooldown)
        self.gaze=gaze; self.waves=waves

    def interact(self,cursor,dt,sculpt):
        self.react(cursor,sculpt)
        previous=self.last_cursor
        self.last_cursor=cursor
        if not cursor:
            self.held=None; self.was_sculpting=False
            return
        x,y=cursor
        distance=0 if previous is None else math.hypot(x-previous[0],y-previous[1])
        if sculpt and not self.world.hidden(x,y):
            if not self.was_sculpting:
                nearby=[b for b in self.balls.values() if math.hypot(b.x-x,b.y-y)<=b.radius+8]
                if nearby:
                    ball=min(nearby,key=lambda b:math.hypot(b.x-x,b.y-y))
                    self.held=ball.uid
                    ball.support=None
            ball=self.balls.get(self.held)
            if ball:
                ball.x=x; ball.y=y
                ball.vx=max(-280,min(280,(x-previous[0])/max(.001,dt)*.5)) if previous else 0
                ball.vy=max(-220,min(220,(y-previous[1])/max(.001,dt)*.5)) if previous else 0
                ball.support=None
            self._collect(cursor,distance,dt)
        elif self.held is not None:
            ball=self.balls.get(self.held)
            self.held=None
            if ball:
                throwing=math.hypot(ball.vx,ball.vy)>110
                if not throwing: ball.vx=0; ball.vy=5
                hit=None if throwing else self._stack_hit(ball,ball.y-20,ball.y+20)
                if hit:
                    ball.y,other=hit; ball.x=other.x
                    ball.support=('ball',other.uid)
        elif previous and distance/max(.001,dt)>640 and not self.world.hidden(x,y):
            dx=x-previous[0]; dy=y-previous[1]
            length2=dx*dx+dy*dy
            for ball in list(self.balls.values()):
                t=max(0,min(1,((ball.x-previous[0])*dx+(ball.y-previous[1])*dy)/max(.001,length2)))
                if math.hypot(previous[0]+t*dx-ball.x,previous[1]+t*dy-ball.y)<ball.radius+4:
                    self.shatter(ball.uid,dx/max(.001,dt)*.12)
        self.was_sculpting=sculpt

    def shatter(self,uid,vx=0):
        from simulation import Particle
        ball=self.balls.pop(uid,None)
        if ball is None: return
        count=max(3,min(12,math.ceil(ball.radius/2)))
        for i in range(count):
            self.world.particles.append(Particle(ball.x+(i/(count-1)-.5)*ball.radius,
                ball.y-ball.radius*.2,vx+self.world.rng.uniform(-65,65),
                -self.world.rng.uniform(20,95),ball.mass/count,None,0,False))
        for other in self.balls.values():
            if other.support==('ball',uid): other.support=None
        if self.held==uid: self.held=None

    def geometry_changed(self,old,current):
        for ball in self.balls.values():
            if not ball.support or ball.support[0]!='roof': continue
            key=ball.support[1]
            if key not in current:
                ball.support=None; ball.vy=10
            elif key in old:
                left,top,right=current[key]
                a,b,c=old[key]
                ball.x=left+(ball.x-a)*(right-left)/max(1,c-a)
                ball.y+=top-b

    def step(self,dt):
        from simulation import Particle
        # Root balls precede descendants; creation order is not a support order.
        pending=set(self.balls)
        for _ in range(len(pending)+1):
            progressed=False
            for uid in list(pending):
                ball=self.balls[uid]
                if ball.support and ball.support[0]=='ball' and ball.support[1] in pending: continue
                pending.remove(uid); progressed=True
                if uid==self.held: continue
                if ball.support:
                    kind,key=ball.support
                    if kind=='roof' and key in self.world.roofs:
                        left,top,right=self.world.roofs[key]
                        if left<=ball.x<right:
                            ball.y=top-self.world.banks[key].height_at(ball.x-left)-ball.radius
                            continue
                    elif kind=='ball' and key in self.balls:
                        other=self.balls[key]
                        ball.x=other.x
                        ball.y=other.y-other.radius-ball.radius+min(ball.radius,other.radius)*.12
                        continue
                    ball.support=None
                old_y=ball.y
                ball.x+=ball.vx*dt
                new_y=old_y+ball.vy*dt+.5*300*dt*dt
                stacked=self._stack_hit(ball,old_y,new_y)
                roof=self.world.collision(ball.x,old_y,new_y,ball.radius)
                stack_y=stacked[0] if stacked else float('inf')
                roof_y=roof[0]-ball.radius if roof else float('inf')
                if stacked and stack_y<=roof_y:
                    ball.y,other=stacked; ball.x=other.x
                    ball.support=('ball',other.uid); ball.vx=ball.vy=0
                elif roof:
                    surface,key,local=roof
                    if ball.vy>240:
                        self.shatter(uid,ball.vx)
                        continue
                    ball.y=surface-ball.radius
                    ball.support=('roof',key); ball.vx=ball.vy=0
                else:
                    ball.y=new_y; ball.vy+=300*dt
                    if ball.y>self.world.height+60 or not -100<ball.x<self.world.width+100:
                        self.world.escaped_mass+=ball.mass
                        del self.balls[uid]
            if not pending or not progressed: break

    def snowmen(self):
        children={b.support[1]:b for b in self.balls.values() if b.support and b.support[0]=='ball'}
        result=[]
        for base in self.balls.values():
            middle=children.get(base.uid)
            head=children.get(middle.uid) if middle else None
            if head and base.support and base.support[0]=='roof' and base.radius>=8 and head.radius>=3:
                result.append((base,middle,head))
        return result

    def scene(self):
        roles={}
        for base,middle,head in self.snowmen():
            roles[base.uid]='base'
            until,_=self.waves.get(base.uid,(0,0))
            roles[middle.uid]='middle:wave' if self.world.time<until else 'middle'
            look=self.gaze.get(head.uid,0)
            roles[head.uid]='head:left' if look<0 else 'head:right' if look>0 else 'head' 
        return [(b.uid,b.x,b.y,b.radius,roles.get(b.uid,'ball')) for b in self.balls.values()]

    @property
    def total_mass(self):
        return sum(b.mass for b in self.balls.values())
