"""Small, bounded visual forces for falling snow."""
import math


def cursor_drift(x,y,vx,vy,cursor,dt,phase=0):
    target_x=target_y=0.0
    if cursor is not None:
        dx=x-cursor[0]; dy=y-cursor[1]
        distance2=dx*dx+dy*dy
        if distance2<48*48:
            distance=math.sqrt(distance2)
            if distance<.01:
                dx,dy=math.cos(phase),math.sin(phase)
                distance=1
            strength=(1-distance/48)**2
            target_x=dx/distance*22*strength
            target_y=dy/distance*8*strength
    blend=1-math.exp(-8*max(0,min(.1,dt)))
    return vx+(target_x-vx)*blend,vy+(target_y-vy)*blend
