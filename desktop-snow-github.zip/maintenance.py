"""Automatic ground-bank maintenance with a visible snowplow."""
from dataclasses import dataclass
import math


@dataclass
class PlowRun:
    key: object
    x: float
    direction: int
    carried: float = 0.0


class SnowPlow:
    TRIGGER_HEIGHT=22
    KEEP_HEIGHT=6
    COOLDOWN=90
    SPEED=115

    def __init__(self,world):
        self.world=world
        self.run=None
        self.next_check=0
        self.cooldowns={}
        self.enabled=True
        self.alternate=1

    def _floors(self):
        return [(key,rect) for key,rect in self.world.roofs.items()
                if isinstance(key,tuple) and key[0]=='floor']

    def start(self,force=False):
        if self.run is not None: return False
        for key,(left,top,right) in self._floors():
            bank=self.world.banks[key]
            if not force:
                if self.world.time<self.cooldowns.get(key,0): continue
                tall=sum(1 for i,m in enumerate(bank.mass)
                         if m/(bank.dx*bank.packing[i])>self.TRIGGER_HEIGHT and
                         not self.world.hidden(left+(i+.5)*bank.dx,top-self.TRIGGER_HEIGHT))
                if tall*bank.dx<24: continue
            direction=self.alternate; self.alternate*=-1
            self.run=PlowRun(key,left-35 if direction>0 else right+35,direction)
            return True
        return False

    def _finish(self):
        if self.run is None: return
        self.world.escaped_mass+=self.run.carried
        self.cooldowns[self.run.key]=self.world.time+self.COOLDOWN
        self.run=None

    def clear(self):
        self._finish()

    def step(self,dt):
        if self.run is None:
            if self.enabled and self.world.time>=self.next_check:
                self.start(); self.next_check=self.world.time+1
            return
        run=self.run
        if run.key not in self.world.roofs:
            self._finish(); return
        left,top,right=self.world.roofs[run.key]
        old=run.x
        run.x+=run.direction*self.SPEED*dt
        # The blade removes only the upper layer under its swept footprint.
        bank=self.world.banks[run.key]
        a=max(0,min(old,run.x)+run.direction*25-left-5)
        b=min(bank.width,max(old,run.x)+run.direction*25-left+5)
        changed=False
        for i in range(max(0,int(a/bank.dx)),min(bank.count,math.ceil(b/bank.dx))):
            x=left+(i+.5)*bank.dx
            if self.world.hidden(x,top-self.KEEP_HEIGHT): continue
            target=self.KEEP_HEIGHT*bank.dx*bank.packing[i]
            amount=max(0,bank.mass[i]-target)
            if amount:
                bank.mass[i]-=amount; run.carried+=amount; changed=True
        if changed: bank.revision+=1
        if run.x>right+45 or run.x<left-45: self._finish()

    def scene(self):
        if self.run is None: return []
        run=self.run
        if run.key not in self.world.roofs: return []
        _,top,_=self.world.roofs[run.key]
        role='plow:right' if run.direction>0 else 'plow:left'
        result=[('snowplow',run.x,top-6,18,role)]
        if run.carried>0:
            radius=min(12,2+math.sqrt(run.carried)*.12)
            result.append(('plowload',run.x+run.direction*31,top-6-radius,radius,'ball'))
        return result

    @property
    def total_mass(self):
        return self.run.carried if self.run else 0
