@echo off
cd /d "%~dp0"
if exist "DesktopSnow.exe" (
  start "" "DesktopSnow.exe"
  exit /b
)
if exist "dist\DesktopSnow.exe" (
  start "" "dist\DesktopSnow.exe"
  exit /b
)
python -c "import PIL, PySide6" >nul 2>&1
if errorlevel 1 (
  echo For the ready-to-run app, download DesktopSnow.exe from Releases.
  echo For source code, install Python and run: python -m pip install -r requirements.txt
  pause
  exit /b 1
)
python snow.py
if errorlevel 1 pause
