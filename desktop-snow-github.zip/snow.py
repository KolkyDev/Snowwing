"""Desktop snowfall for Windows."""
import ctypes as C
from ctypes import wintypes as W
import math
import random
import sys
import time
from rendering import Surface
from simulation import SnowWorld, Particle
from effects import cursor_drift

if sys.platform != 'win32':
    raise SystemExit('Desktop Snow requires Windows.')

user32=C.WinDLL('user32',use_last_error=True)
try:
    C.windll.shcore.SetProcessDpiAwareness(2)
except (AttributeError,OSError):
    user32.SetProcessDPIAware()
ENUMPROC=C.WINFUNCTYPE(W.BOOL,W.HWND,W.LPARAM)
user32.EnumWindows.argtypes=[ENUMPROC,W.LPARAM]
user32.GetWindowRect.argtypes=[W.HWND,C.POINTER(W.RECT)]
user32.IsWindowVisible.argtypes=[W.HWND]
user32.IsIconic.argtypes=[W.HWND]
user32.GetCursorPos.argtypes=[C.POINTER(W.POINT)]
user32.GetAsyncKeyState.argtypes=[C.c_int]
user32.GetAsyncKeyState.restype=C.c_short


class Snow:
    ACCUMULATION_RATE = 6.0

    def __init__(self):
        self.x=user32.GetSystemMetrics(76)
        self.y=user32.GetSystemMetrics(77)
        self.width=user32.GetSystemMetrics(78)
        self.height=user32.GetSystemMetrics(79)
        self.surface=Surface(self.x,self.y,self.width,self.height)
        self.hwnd=self.surface.hwnd
        self.world=SnowWorld(self.width,self.height)
        self.flakes=[]
        self.paused=False
        self.running=True
        self.accumulate=True
        self.on_windows=True
        self.intensity=1.0
        self.last=time.perf_counter()
        self.scan_at=0
        self.snow_time=0
        self.test_snow_until=0
        self.test_snow_credit=0
        self.surface.install_controls(self)
        self.reset_flakes()

    def reset_flakes(self):
        count=min(480,int(min(360,max(100,self.width/12))*self.intensity))
        while len(self.flakes)<count:
            kind=random.choices(range(4),weights=(28,42,24,6))[0]
            self.flakes.append([random.uniform(0,self.width),random.uniform(-100,self.height),
                random.uniform(95,190)*(.9+kind*.10),(.85,1.15,1.65,2.1)[kind],
                random.uniform(0,math.tau),kind,0.0,0.0])
        del self.flakes[count:]

    def clear(self):
        for bank in self.world.banks.values(): bank.drain()
        self.world.particles.clear()
        self.world.toys.balls.clear()
        self.world.toys.held=None
        self.world.plow.clear()
        self.test_snow_until=0

    def pour_test_snow(self):
        self.test_snow_until=self.snow_time+8
        self.test_snow_credit=0

    def raise_test_drift(self):
        for key,(left,top,right) in self.world.roofs.items():
            if isinstance(key,tuple) and key[0]=='floor':
                width=min(400,right-left)
                self.world.banks[key].deposit((right-left)/2,width*32*.3,spread=max(12,width/5))
                break

    def scan_windows(self):
        windows=[]
        @ENUMPROC
        def visit(hwnd,_):
            if hwnd==self.hwnd or not user32.IsWindowVisible(hwnd) or user32.IsIconic(hwnd):
                return True
            name=C.create_unicode_buffer(256)
            user32.GetClassNameW(W.HWND(hwnd),name,256)
            if name.value in ('Progman','WorkerW','tooltips_class32'):
                return True
            rect=W.RECT()
            if not user32.GetWindowRect(hwnd,C.byref(rect)): return True
            try:
                cloaked=W.DWORD()
                C.windll.dwmapi.DwmGetWindowAttribute(W.HWND(hwnd),14,C.byref(cloaked),C.sizeof(cloaked))
                if cloaked.value: return True
                visual=W.RECT()
                if C.windll.dwmapi.DwmGetWindowAttribute(W.HWND(hwnd),9,C.byref(visual),C.sizeof(visual))==0:
                    rect=visual
            except (AttributeError,OSError):
                pass
            left,top=rect.left-self.x,rect.top-self.y
            right,bottom=rect.right-self.x,rect.bottom-self.y
            if right-left>20 and bottom-top>20:
                windows.append((int(hwnd),left,top,right,bottom,name.value))
            return True
        user32.EnumWindows(visit,0)
        roofs=[]
        if self.on_windows:
            for hwnd,left,top,right,bottom,name in windows:
                if 3<top<self.height and right>0 and left<self.width and name not in ('Shell_TrayWnd','Shell_SecondaryTrayWnd'):
                    roofs.append((left,top,right,hwnd))
        MONITORPROC=C.WINFUNCTYPE(W.BOOL,W.HANDLE,W.HDC,C.POINTER(W.RECT),W.LPARAM)
        class MonitorInfo(C.Structure):
            _fields_=[('size',W.DWORD),('monitor',W.RECT),('work',W.RECT),('flags',W.DWORD)]
        @MONITORPROC
        def monitor(handle,dc,rect,data):
            info=MonitorInfo(); info.size=C.sizeof(info)
            if user32.GetMonitorInfoW(W.HANDLE(handle),C.byref(info)):
                r=info.work
                roofs.append((r.left-self.x,r.bottom-self.y,r.right-self.x,('floor',int(handle))))
            return True
        user32.EnumDisplayMonitors(None,None,monitor,0)
        self.world.set_geometry(roofs,[(a,b,c,d) for _,a,b,c,d,_ in windows])

    def tick(self):
        now=time.perf_counter()
        dt=min(.1,now-self.last)
        self.last=now
        if now>=self.scan_at:
            self.scan_windows()
            self.scan_at=now+.075
        if not self.paused:
            point=W.POINT()
            cursor=(point.x-self.x,point.y-self.y) if user32.GetCursorPos(C.byref(point)) else None
            sculpt=bool(user32.GetAsyncKeyState(0x11)&0x8000)
            self.world.step(dt,cursor,sculpt=sculpt)
            self.snow_time+=dt
        cursor=self.world.last_cursor if not self.paused else None
        if cursor and self.world.hidden(*cursor): cursor=None
        if not self.paused and self.snow_time<self.test_snow_until:
            self.test_snow_credit+=dt*20
            while self.test_snow_credit>=1:
                self.test_snow_credit-=1
                x,y=cursor if cursor else (self.width/2,20)
                self.world.particles.append(Particle(x+random.uniform(-14,14),y-12,
                    random.uniform(-8,8),70,4))
        draw=[]
        for f in self.flakes:
            x,y,speed,radius,phase,index,vx,vy=f
            if not self.paused:
                vx,vy=cursor_drift(x,y,vx,vy,cursor,dt,phase)
                nx=(x+(math.sin(self.snow_time*.7+phase)*14+5+vx)*dt)%self.width
                ny=y+(speed+vy)*dt
                hit=self.world.collision(nx,y,ny,radius) if self.accumulate else None
                if hit:
                    _,key,local=hit
                    self.world.deposit(key,local,math.pi*radius*radius*.27*self.ACCUMULATION_RATE)
                if hit or ny>self.height+10:
                    nx,ny=random.uniform(0,self.width),random.uniform(-70,-5)
                    vx=vy=0
                f[0],f[1],f[6],f[7]=nx,ny,vx,vy
            if not self.world.hidden(f[0],f[1],radius+2):
                draw.append((f[0],f[1],index,1.0))
        for p in self.world.particles:
            scale=min(2.4,max(.7,math.sqrt(p.mass)/2))
            if not self.world.hidden(p.x,p.y,scale*3):
                draw.append((p.x,p.y,1,scale))
        banks=[(left,top,right,key,self.world.banks[key].heights)
               for key,(left,top,right) in self.world.roofs.items()]
        self.surface.present(banks,draw,self.world.blockers,self.world.toys.scene()+self.world.plow.scene())

    def run(self):
        try:
            while self.running and not getattr(self,'stop_requested',lambda:False)():
                started=time.perf_counter()
                self.surface.pump()
                self.tick()
                time.sleep(max(0,1/30-(time.perf_counter()-started)))
        except KeyboardInterrupt:
            pass
        finally:
            self.surface.close()


def self_check():
    """Check packaged imports, physics and Qt plugins without showing the overlay."""
    import os
    os.environ['QT_QPA_PLATFORM']='offscreen'
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QImage,QPainter,QRegion
    from PySide6.QtWidgets import QApplication
    from rendering import SnowLayer,qt_sprite,flake
    app=QApplication.instance() or QApplication([])
    world=SnowWorld(320,200,seed=1)
    world.set_geometry([(0,180,320,('floor',1))],[])
    for _ in range(6): world.step(1/30)
    layer=SnowLayer(320,200,[qt_sprite(flake(1,(230,240,255),180))]*4)
    layer.set_scene([(0,180,320,'floor',world.banks[('floor',1)].heights)],[(100,80,0,1)],[])
    image=QImage(320,200,QImage.Format.Format_ARGB32_Premultiplied)
    image.fill(Qt.GlobalColor.transparent)
    painter=QPainter(image)
    layer.paint_scene(painter,QRegion(layer.rect()))
    painter.end()
    if image.pixelColor(100,80).alpha()==0: raise RuntimeError('Rendering check failed')
    layer.close()
    return 0


def main():
    if '--check' in sys.argv: return self_check()
    kernel = C.WinDLL('kernel32', use_last_error=True)
    kernel.CreateMutexW.argtypes = [C.c_void_p, W.BOOL, W.LPCWSTR]
    kernel.CreateMutexW.restype = W.HANDLE
    kernel.CreateEventW.argtypes = [C.c_void_p, W.BOOL, W.BOOL, W.LPCWSTR]
    kernel.CreateEventW.restype = W.HANDLE
    kernel.OpenEventW.argtypes = [W.DWORD, W.BOOL, W.LPCWSTR]
    kernel.OpenEventW.restype = W.HANDLE
    kernel.SetEvent.argtypes = [W.HANDLE]
    kernel.WaitForSingleObject.argtypes = [W.HANDLE, W.DWORD]
    kernel.CloseHandle.argtypes = [W.HANDLE]
    event_name = 'Local\\DesktopSnow.Stop'
    if '--stop' in sys.argv:
        event = kernel.OpenEventW(2, False, event_name)
        if event:
            kernel.SetEvent(event)
            kernel.CloseHandle(event)
            print('Snow stop requested.')
        else:
            print('Snow is not running.')
        return
    mutex = kernel.CreateMutexW(None, False, 'Local\\DesktopSnow.Instance')
    error = C.get_last_error()
    if not mutex:
        raise C.WinError(error)
    if error == 183:
        kernel.CloseHandle(mutex)
        print('Snow is already running. Use stop.bat to stop it.')
        return
    event = kernel.CreateEventW(None, True, False, event_name)
    if not event:
        kernel.CloseHandle(mutex)
        raise C.WinError(C.get_last_error())
    try:
        app = Snow()
        app.stop_requested = lambda: kernel.WaitForSingleObject(event, 0) == 0
        app.run()
    finally:
        kernel.CloseHandle(event)
        kernel.CloseHandle(mutex)


if __name__ == '__main__':
    try:
        result=main()
    except Exception as error:
        if '--check' not in sys.argv:
            user32.MessageBoxW(None,'?? ??????? ????????? Desktop Snow.\n'+str(error),
                              'Desktop Snow',0x10)
        result=1
    raise SystemExit(result or 0)
