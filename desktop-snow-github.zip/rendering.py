"""Antialiased snow particles and a transparent Qt desktop layer."""
import os
import sys
from pathlib import Path
os.environ.setdefault("QT_ENABLE_HIGHDPI_SCALING", "0")
import math
import time
from PIL import Image, ImageDraw, ImageFilter


def flake(radius, shade, opacity):
    scale = 4
    size = max(8, math.ceil(radius * 2 + 6))
    image = Image.new('RGBA', (size * scale, size * scale))
    draw = ImageDraw.Draw(image)
    c = size * scale / 2
    r = radius * scale
    draw.ellipse((c-r, c-r, c+r, c+r), fill=(*shade, opacity))
    image = image.filter(ImageFilter.GaussianBlur(.32 * scale))
    return image.resize((size, size), Image.Resampling.LANCZOS)


from PySide6.QtCore import Qt, QRect, QRectF, QPointF
from PySide6.QtGui import (QActionGroup, QIcon, QPixmap, QBrush, QColor, QImage, QLinearGradient, QRadialGradient,
                          QPainter, QPainterPath, QPen, QRegion)
from PySide6.QtWidgets import QApplication, QWidget, QSystemTrayIcon, QMenu


def qt_sprite(image):
    return QImage(image.tobytes(), image.width, image.height,
                  image.width*4,QImage.Format.Format_RGBA8888).convertToFormat(
                      QImage.Format.Format_ARGB32_Premultiplied)


class SnowLayer(QWidget):
    def __init__(self,width,height,sprites):
        super().__init__(None,Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool |
                         Qt.WindowType.WindowStaysOnTopHint |
                         Qt.WindowType.WindowTransparentForInput |
                         Qt.WindowType.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setWindowTitle('Desktop Snow')
        self.resize(width,height)
        self.sprites=sprites
        self.caps={}
        self.flakes=[]
        self.toys=[]
        self.toy_images={}
        self.visible_region=QRegion(self.rect())
        self.blockers=[]
        self.grain=QImage(64,32,QImage.Format.Format_ARGB32_Premultiplied)
        self.grain.fill(Qt.GlobalColor.transparent)
        import random
        rng=random.Random(73)
        painter=QPainter(self.grain)
        for _ in range(170):
            painter.setPen(QColor(255,255,255,rng.randrange(8,28)))
            painter.drawPoint(rng.randrange(64),rng.randrange(32))
        painter.end()

    def toy_image(self,radius,role):
        key=(round(radius*4),role)
        if key in self.toy_images: return self.toy_images[key]
        base_role=role.split(":",1)[0]
        r=max(.2,key[0]/4)
        size=max(12,math.ceil(r*3.8+12))
        image=QImage(size,size,QImage.Format.Format_ARGB32_Premultiplied)
        image.fill(Qt.GlobalColor.transparent)
        p=QPainter(image)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.translate(size/2,size/2)
        if base_role=='plow':
            if role.endswith('left'): p.scale(-1,1)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(38,49,62))
            for x in (-16,17): p.drawEllipse(QPointF(x,0),6,6)
            p.setBrush(QColor(93,115,134))
            p.drawRoundedRect(QRectF(-27,-19,48,15),3,3)
            p.setBrush(QColor(180,140,74))
            p.drawRoundedRect(QRectF(2,-32,19,21),3,3)
            p.setBrush(QColor(144,185,207))
            p.drawRoundedRect(QRectF(6,-28,11,10),1,1)
            p.setBrush(QColor(218,169,84))
            p.drawEllipse(QPointF(12,-34),2,2)
            blade=QPainterPath(); blade.moveTo(27,-14); blade.lineTo(35,-11)
            blade.lineTo(33,5); blade.lineTo(25,5); blade.closeSubpath()
            p.fillPath(blade,QColor(154,178,196))
            p.setPen(QPen(QColor(173,192,207),1.2));p.drawLine(QPointF(18,-6),QPointF(28,-4))
            p.end();self.toy_images[key]=image
            return image
        gradient=QRadialGradient(QPointF(-r*.3,-r*.4),r*1.8)
        gradient.setColorAt(0,QColor(255,255,255))
        gradient.setColorAt(.6,QColor(231,242,253))
        gradient.setColorAt(1,QColor(153,181,211))
        p.setBrush(QBrush(gradient))
        p.setPen(QPen(QColor(212,229,246,180),.6))
        p.drawEllipse(QRectF(-r,-r,2*r,2*r))
        p.setPen(Qt.PenStyle.NoPen)
        if base_role=='middle':
            p.setBrush(QColor(47,61,76))
            for y in (-.2,.3): p.drawEllipse(QPointF(0,y*r),max(.8,r*.09),max(.8,r*.09))
            p.setPen(QPen(QColor(106,74,49),max(1,r*.10)))
            for side in (-1,1):
                raised=role.endswith('wave') and side==1
                end_y=-r*1.2 if raised else -r*.65
                p.drawLine(QPointF(side*r*.8,-r*.1),QPointF(side*r*1.65,end_y))
                p.drawLine(QPointF(side*r*1.35,end_y+r*.2),QPointF(side*r*1.45,end_y-r*.2))
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(166,55,63))
            p.drawRoundedRect(QRectF(-r*.65,-r*.8,r*1.3,r*.22),r*.08,r*.08)
            p.drawRoundedRect(QRectF(r*.2,-r*.7,r*.24,r*.65),r*.05,r*.05)
        elif base_role=='head':
            p.setBrush(QColor(40,52,65))
            gaze=-.1 if role.endswith('left') else .1 if role.endswith('right') else 0
            for x in (-.28,.28): p.drawEllipse(QPointF((x+gaze)*r,-r*.25),max(.7,r*.10),max(.7,r*.10))
            carrot=QPainterPath(); carrot.moveTo(0,-r*.02)
            carrot.lineTo(r*.92,r*.12); carrot.lineTo(0,r*.24); carrot.closeSubpath()
            p.fillPath(carrot,QColor(224,133,50))
            p.setBrush(QColor(55,74,91))
            p.drawRoundedRect(QRectF(-r*.65,-r*1.55,r*1.3,r*.65),r*.1,r*.1)
            p.drawRoundedRect(QRectF(-r*.9,-r*1.0,r*1.8,r*.16),r*.05,r*.05)
        p.end()
        self.toy_images[key]=image
        return image

    def set_scene(self,banks,flakes,blockers,toys=None):
        toys=[] if toys is None else toys
        regions=[]
        old={toy[0]:toy for toy in self.toys}
        new={toy[0]:toy for toy in toys}
        for uid in old.keys()|new.keys():
            if old.get(uid)==new.get(uid): continue
            for toy in (old.get(uid),new.get(uid)):
                if toy is None: continue
                _,x,y,r,role=toy
                image=self.toy_image(r,role)
                regions.append(QRegion(QRectF(x-image.width()/2-1,y-image.height()/2-1,
                                              image.width()+2,image.height()+2).toAlignedRect()))
        self.toys=toys
        current={}
        for left,top,right,key,heights in banks:
            if not heights or max(heights)<.06:
                continue
            signature=(left,top,right,tuple(round(h*4) for h in heights))
            cached=self.caps.get(key)
            if cached and (cached[0]==signature or (cached[0][:3]==signature[:3] and time.perf_counter()<cached[6])):
                current[key]=cached
                continue
            crest=QPainterPath()
            crest.moveTo(left,top-heights[0])
            for i,h in enumerate(heights[1:],1):
                crest.lineTo(left+(right-left)*i/(len(heights)-1),top-h)
            path=QPainterPath(crest)
            path.lineTo(right,top); path.lineTo(left,top); path.closeSubpath()
            bounds=path.boundingRect().adjusted(-2,-2,2,2).toAlignedRect()
            gradient=QLinearGradient(0,top-max(heights),0,top)
            gradient.setColorAt(0,QColor(251,253,255))
            gradient.setColorAt(.40,QColor(234,244,253))
            gradient.setColorAt(1,QColor(177,201,226))
            brush=QBrush(gradient)
            image=QImage(bounds.width(),bounds.height(),QImage.Format.Format_ARGB32_Premultiplied)
            image.fill(Qt.GlobalColor.transparent)
            cap_painter=QPainter(image)
            cap_painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            cap_painter.translate(-bounds.left(),-bounds.top())
            cap_painter.fillPath(path,brush)
            cap_painter.save()
            cap_painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceAtop)
            cap_painter.fillRect(bounds,QBrush(self.grain))
            cap_painter.restore()
            cap_painter.setPen(QPen(QColor(255,255,255,185),.75))
            cap_painter.drawPath(crest)
            cap_painter.end()
            current[key]=(signature,path,crest,bounds,brush,image,time.perf_counter()+1/15)
            regions.append(QRegion(bounds))
            if cached: regions.append(QRegion(cached[3]))
        for key,cached in self.caps.items():
            if key not in current: regions.append(QRegion(cached[3]))
        for x,y,index,scale in self.flakes+flakes:
            image=self.sprites[index]
            w=image.width()*scale; h=image.height()*scale
            regions.append(QRegion(QRectF(x-w/2-1,y-h/2-1,w+2,h+2).toAlignedRect()))
        if blockers != self.blockers:
            self.visible_region=QRegion(self.rect())
            for a,b,c,d in blockers:
                self.visible_region=self.visible_region.subtracted(QRegion(QRect(a,b,max(0,c-a+1),max(0,d-b+1))))
            # Erase old occlusion and expose newly visible background.
            regions=[QRegion(self.rect())]
            self.blockers=list(blockers)
        self.caps=current
        self.flakes=flakes
        used={(round(toy[3]*4),toy[4]) for toy in self.toys}
        self.toy_images={key:image for key,image in self.toy_images.items() if key in used}
        # A balanced union avoids repeatedly copying an ever-growing region.
        while len(regions)>1:
            regions=[regions[i].united(regions[i+1]) if i+1<len(regions) else regions[i]
                     for i in range(0,len(regions),2)]
        if regions and not regions[0].isEmpty(): self.update(regions[0])

    def paintEvent(self,event):
        painter=QPainter(self)
        self.paint_scene(painter,event.region())
        painter.end()

    def paint_scene(self,painter,dirty):
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        painter.setClipRegion(dirty.intersected(self.visible_region))
        for cached in self.caps.values():
            bounds=cached[3]
            if dirty.intersects(bounds):
                painter.drawImage(bounds.topLeft(),cached[5])
        for _,x,y,r,role in self.toys:
            image=self.toy_image(r,role)
            rect=QRectF(x-image.width()/2,y-image.height()/2,image.width(),image.height())
            if dirty.intersects(rect.toAlignedRect()): painter.drawImage(rect,image)
        for x,y,index,scale in self.flakes:
            image=self.sprites[index]
            w=image.width()*scale; h=image.height()*scale
            rect=QRectF(x-w/2,y-h/2,w,h)
            if dirty.intersects(rect.toAlignedRect()):
                painter.drawImage(rect,image)


class Surface:
    def __init__(self,x,y,width,height):
        self.app=QApplication.instance() or QApplication([])
        self.app.setQuitOnLastWindowClosed(False)
        sprites=[qt_sprite(flake(r,color,opacity)) for r,color,opacity in [
            (.85,(193,210,234),110),(1.15,(222,234,249),150),
            (1.65,(244,249,255),195),(2.1,(232,242,255),145)]]
        self.layer=SnowLayer(width,height,sprites)
        self.layer.move(x,y)
        self.hwnd=int(self.layer.winId())
        self.layer.show()

    def install_controls(self,owner):
        resources=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
        icon=QIcon(str(resources/'assets'/'snow.ico'))
        if icon.isNull(): icon=QIcon(QPixmap.fromImage(self.layer.sprites[2]))
        self.app.setWindowIcon(icon)
        self.layer.setWindowIcon(icon)
        self.tray=QSystemTrayIcon(icon,self.layer)
        self.tray.setToolTip('Desktop Snow')
        self.menu=QMenu()
        pause=self.menu.addAction('?????'); pause.setCheckable(True)
        pause.toggled.connect(lambda checked:setattr(owner,'paused',checked))
        intensity=self.menu.addMenu('????????')
        group=QActionGroup(intensity); group.setExclusive(True)
        for label,value in [('??????',.5),('???????',1.0),('???????',1.7)]:
            action=intensity.addAction(label); action.setCheckable(True)
            action.setChecked(value==1.0); group.addAction(action)
            def choose(checked,v=value):
                if checked:
                    owner.intensity=v; owner.reset_flakes()
            action.toggled.connect(choose)
        accumulate=self.menu.addAction('?????????? ?????'); accumulate.setCheckable(True); accumulate.setChecked(True)
        accumulate.toggled.connect(lambda checked:setattr(owner,'accumulate',checked))
        windows=self.menu.addAction('???? ?? ?????'); windows.setCheckable(True); windows.setChecked(True)
        windows.toggled.connect(lambda checked:setattr(owner,'on_windows',checked))
        toys=self.menu.addMenu('??????')
        hint=toys.addAction('Ctrl + ???????? ? ??????? ? ?????????')
        hint.setEnabled(False)
        hint=toys.addAction('??????? Ctrl ??? ????? ? ?????????')
        hint.setEnabled(False)
        toys.addAction('????????? ??? ??????').triggered.connect(
            lambda:[owner.world.toys.shatter(uid) for uid in list(owner.world.toys.balls)])
        plow=self.menu.addMenu('????????????')
        automatic=plow.addAction('?????????????? ??????');automatic.setCheckable(True);automatic.setChecked(True)
        automatic.toggled.connect(lambda enabled:setattr(owner.world.plow,'enabled',enabled))
        plow.addAction('?????? ???? ??????').triggered.connect(lambda:owner.world.plow.start(force=True))
        test=self.menu.addMenu('???????? ????')
        test.addAction('?????? ??? ???????? 8 ??????').triggered.connect(owner.pour_test_snow)
        test.addAction('???????? ??????? ??????').triggered.connect(owner.raise_test_drift)
        self.menu.addAction('???????? ???? ????').triggered.connect(owner.clear)
        self.menu.addSeparator()
        self.menu.addAction('?????').triggered.connect(lambda:setattr(owner,'running',False))
        self.tray.setContextMenu(self.menu)
        self.tray.show()
        if QSystemTrayIcon.supportsMessages():
            self.tray.showMessage('Desktop Snow','???? ???????. ?????? ???? ?? ???????? ? ???? ? ???? ? ?????.',
                                  QSystemTrayIcon.MessageIcon.Information,4500)

    def present(self,banks,flakes,blockers,toys=None):
        self.layer.set_scene(banks,flakes,blockers,toys)

    def pump(self):
        self.app.processEvents()

    def close(self):
        if hasattr(self,'tray'): self.tray.hide()
        self.layer.close()
        self.app.processEvents()
