"""Build the standalone Windows executable."""
import os
from pathlib import Path
import sys


def main():
    root=Path(__file__).resolve().parent
    local_tools=root/'.build-tools'
    if local_tools.is_dir():
        sys.path.insert(0,str(local_tools))
        os.environ['PYTHONPATH']=str(local_tools)+os.pathsep+os.environ.get('PYTHONPATH','')
    os.environ['PYINSTALLER_CONFIG_DIR']=str(root/'.build-cache')
    try:
        import PyInstaller.__main__
    except ImportError:
        raise SystemExit('Install build requirements first: python -m pip install -r requirements-build.txt')
    PyInstaller.__main__.run([
        '--noconfirm','--clean','--onefile','--windowed','--noupx',
        '--name','DesktopSnow','--icon',str(root/'assets'/'snow.ico'),
        '--version-file',str(root/'version_info.txt'),
        '--distpath',str(root/'dist'),'--workpath',str(root/'.build-work'),
        '--specpath',str(root/'.build-work'),
        '--add-data',str(root/'assets'/'snow.ico')+';assets',
        '--add-data',str(root/'THIRD_PARTY_NOTICES.txt')+';.',
        '--add-data',str(root/'licenses')+';licenses',
        '--exclude-module','tkinter','--exclude-module','numpy',
        '--exclude-module','matplotlib','--exclude-module','pandas',
        '--exclude-module','PySide6.QtWebEngineCore',
        '--exclude-module','PySide6.QtWebEngineWidgets',
        '--exclude-module','PySide6.QtQuick','--exclude-module','PySide6.QtQml',
        str(root/'snow.py')])
    print('Ready: dist/DesktopSnow.exe')


if __name__=='__main__': main()
